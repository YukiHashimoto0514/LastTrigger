//@file MoveAndStop.h

#ifndef COMPONENT_MOVEANDSTOP_H_INCLUDED
#define COMPONENT_MOVEANDSTOP_H_INCLUDED

#include "../Component.h"
#include "../GameObject.h"

class MoveAndStop :public Component
{
public:
	MoveAndStop() = default;			//�R���X�g���N�^
	virtual ~MoveAndStop() = default;	//�f�X�g���N�^

	virtual void Update(GameObject& gameObject, float deltaTime)override
	{
		a += deltaTime / Stop;
		if (a > 1)
		{
			Timer += a;
			a = 0;
		}
		if (Timer % 2 == 0)
		{
			gameObject.x += vx * deltaTime;
			gameObject.y += vy * deltaTime;
		}
	}

	float vx = 0;
	float vy = 0;
	int Stop = 1;//�~�܂�܂ł̎���

private:
	int Timer = 0;	//�o�ߎ���
	float a = 0;
};



#endif //COMPONENT_MOVEANDSTOP_H_INCLUDED
