//@file angleMOVE.h

#ifndef COMPONENT_ANGlEMOVE_H_INCLUDED

#define COMPONENT_ANGlEMOVE_H_INCLUDED

#include "../Component.h"
#include "../GameObject.h"
#include <math.h>

//�Q�[���I�u�W�F�N�g���ړ�����
class angleMove :public Component
{
public:
	angleMove() = default;//�R���X�g���N�^
	virtual ~angleMove() = default;//�f�X�g���N�^

	virtual void Start(GameObject& gameObject)override
	{
		a = rand()%180;
		b = rand()%180;
	}

	virtual void Update(GameObject& gameObject, float deltaTime)override
	{
		c = sqrt(a * a + b * b);
		gameObject.x += cos(c)*vx * deltaTime;
		gameObject.y += vy * deltaTime;
	}

	float vx = 0;
	float vy = 0;

	int a, b;
	int c;
};




#endif //COMPONENT_ANGlEMOVE_H_INCLUDED
